import test, { expect } from '@playwright/test'


let acc_Token:any
let inst_Url:any
let token_Type:any

let SF_Id:any

test("Generate Token",async({request})=>{


    let tokenRes=await request.post("https://login.salesforce.com/services/oauth2/token",{
        headers:{
            "Content-Type":"application/x-www-form-urlencoded",
            "Connection":"keep-alive"
        },
        form:{
            "grant_type":"password",
            "username":"manikandanleo4922@agentforce.com",
            "password":"India@2026", 
            "client_id":"3MVG9dAEux2v1sLs_5LgrWbWWJbMYKRgBajBibwGyik0pC_tXNFGsk6aV8h1owvGj6hsaxRWhzGX5WP1O87h5",
            "client_secret":"EE7E666EF8204C869125AC8160C78B0F93277C544B84F8B89A0D59AD9FB3AD1C"
        }
    })
let res=await tokenRes.json()
acc_Token=res.access_token
inst_Url=res.instance_url
token_Type=res.token_type

//console.log(acc_Token,inst_Url,token_Type)

})


test("Create Lead Using Post Request",async({request})=>{

    let postRes=await request.post(`${inst_Url}/services/data/v65.0/sobjects/Lead/`,{
        headers:{
            "Content-Type":"application/json",
            "Authorization":`${token_Type} ${acc_Token}`
        },
        data:{
"firstname":"Dinesh",
"lastname": "Kumar",
"company":"TestLeaf"
        }

    })

    let res=await postRes.json()
    SF_Id=res.id
    console.log(SF_Id)
    expect(res.id).toEqual(SF_Id)



})